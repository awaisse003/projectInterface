A Pen created at CodePen.io. You can find this one at https://codepen.io/nicklassandell/pen/cqlGk.

 Credit for design goes to Vivek Venkatraman:
http://dribbble.com/shots/1455744-Email-Concept/

Check it out in full view to see it's responsiveness. It's responsive until pretty darn small but i haven't actually tested it on mobile devices. Tested in IE9+, latest Chrome and Firefox.

I've noticed the message (slide-in section) is some times visible on page load. If that's the case just reload the page, that's a browser bug.